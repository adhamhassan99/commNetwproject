import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;


public class TCPclient {
	static Socket client;
	public static void main(String[] args) throws IOException {
		String msg;
		String rply;
		
		BufferedReader inUser=new BufferedReader(new InputStreamReader(System.in));
		
		msg=inUser.readLine();
		if(msg.equals("CONNECT")){
			client=new Socket("localhost",801);
			System.out.println("connected");
//			DataOutputStream outServer=new DataOutputStream(client.getOutputStream());
//			BufferedReader inn=new BufferedReader(new InputStreamReader(client.getInputStream()));
//			System.out.println("connected");
//			System.out.println("from client: ");
//			msg=inUser.readLine();
//			outServer.writeBytes(msg+ '\n');
			
			while(true){
				DataOutputStream outServer=new DataOutputStream(client.getOutputStream());
				BufferedReader inn=new BufferedReader(new InputStreamReader(client.getInputStream()));
				System.out.println("from client: ");
				msg=inUser.readLine();
				outServer.writeBytes(msg+ '\n');
				rply=inn.readLine();
				System.out.println("server: "+rply);
			if(msg.equals("CLOSE")){
				System.out.println("bye");
				outServer.writeBytes(msg);
				outServer.close();
				break;
			}
			
		
		}
		}		else{
			System.out.println("connection failed");
		}
	}

}