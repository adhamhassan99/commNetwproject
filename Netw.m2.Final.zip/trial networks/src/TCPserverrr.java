import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;


public class TCPserverrr {
	static ServerSocket  welcomesocket;
public static void main(String[] args) throws IOException {
	String client;
	String server;
	
	welcomesocket=new ServerSocket(801);
	Socket connectionsocket=welcomesocket.accept();

	BufferedReader inFromuser=new BufferedReader(new InputStreamReader(System.in));
	BufferedReader inFromClient;
	DataOutputStream outToClient;
	
	while(true){
		inFromClient=new BufferedReader(new InputStreamReader(connectionsocket.getInputStream()));
		
		outToClient=new DataOutputStream(connectionsocket.getOutputStream());
		
		client=inFromClient.readLine();
		
		System.out.println("from client: "+client);
		if(client.equals("close")){
			System.out.println("bye");
			outToClient.close();
			break;
		}
			System.out.println("from server: ");
			server=inFromuser.readLine()+ '\n';
			outToClient.writeBytes(server);
			
			
			
	}
}
}
