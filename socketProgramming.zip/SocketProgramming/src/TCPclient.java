import java.io.*; 
import java.net.*; 
public class TCPclient {
	public static void main(String argv[]) throws Exception 
    { 

	String message;
	String capMessage;
	 BufferedReader userInput=new BufferedReader(new InputStreamReader(System.in));
	 Socket clientsocket=new Socket("localhost", 9876);
	 DataOutputStream toServer =new DataOutputStream(clientsocket.getOutputStream());
	 BufferedReader ServerResponse=new BufferedReader(new InputStreamReader(clientsocket.getInputStream()));
	 System.out.println("enter mesg");
	 message=userInput.readLine();
	 userInput.close();
	 toServer.writeBytes(message+'\n');
	 capMessage=ServerResponse.readLine();
	 System.out.println("from server "+capMessage);
	 clientsocket.close();
	 
	 
}
}