import java.io.*; 
import java.net.*; 

import javax.xml.bind.ValidationEvent;
public class TCPserver {
	  public static void main(String argv[]) throws Exception 
	    { 

	String message;
	String capMessage;
	
	
	
	ServerSocket reciever = new ServerSocket(9876);
	while(true) { 
		  
        Socket connectionSocket = reciever.accept();
        BufferedReader clientInput = new BufferedReader(new InputStreamReader(connectionSocket.getInputStream()));
        DataOutputStream response=new DataOutputStream(connectionSocket.getOutputStream());
        message = clientInput.readLine(); 
        capMessage=message.toUpperCase()+'\n';
        response.writeBytes(capMessage);
        
	}
	
}}
